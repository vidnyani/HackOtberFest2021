#Importing the Required Libraries and Modules
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.patches as mpatches

#Importing the Necessary Data
google_csv=pd.read_csv("D:\Ajmal\Project\Revenue\Google 2012-20.csv")
yahoo_csv=pd.read_csv("D:\Ajmal\Project\Revenue\Yahoo 2012-20.csv")
netflix_csv=pd.read_csv("D:\Ajmal\Project\Revenue\wNetflix 2012-20.csv")


