reply=str(input("Would you like to start? (Y/N): "))
yes=['yes','Y']
no=['No','N']
if reply in yes:
        import Final.py
elif reply in no:
    print('Thank you For using')
    
