import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.patches as mpatches

google_csv=pd.read_csv("D:\Ajmal\Project\Google 2012-20.csv")
print(google_csv)
google_data=np.genfromtxt("D:\Ajmal\Project\Google 2012-20.csv",delimiter=",",names=["x", "y"])
yahoo_csv=pd.read_csv("D:\Ajmal\Project\Yahoo 2012-20.csv")
print(yahoo_csv)
yahoo_data=np.genfromtxt("D:\Ajmal\Project\Yahoo 2012-20.csv",delimiter=",",names=["x", "y"])
netflix_csv=pd.read_csv("D:\Ajmal\Project\wNetflix 2012-20.csv")
print(netflix_csv)
netflix_data=np.genfromtxt("D:\Ajmal\Project\wNetflix 2012-20.csv",delimiter=",",names=["x", "y"])
plt.plot(google_data['x'],google_data['y'],yahoo_data['x'],yahoo_data['y'],netflix_data['x'],netflix_data['y'])
#plt.plot(yahoo_data['x'],yahoo_data['y'])
#plt.plot(google_data['x'],google_data['y'],yahoo_data['x'],yahoo_data['y'])
google_patch=mpatches.Patch(color="blue",label="Google")
nflx_patch=mpatches.Patch(color="green",label="Netflix")
yahoo_patch=mpatches.Patch(color="orange",label="Yahoo")
plt.xlabel("Years")
plt.ylabel("Revenue")
plt.legend(handles=[google_patch,yahoo_patch,nflx_patch])
plt.rcParams.update(plt.rcParamsDefault)
plt.style.use('grayscale')
plt.show()

#yahoo_csv=pd.read_csv("D:\Ajmal\Project\Yahoo 2012-20.csv")
#print(yahoo_csv)
#yahoo_data=np.genfromtxt("D:\Ajmal\Project\Google 2012-20.csv",delimiter=",",names=["x", "y"])
#plt.plot(yahoo_data['x'],yahoo_data['y'])
#plt.show()
